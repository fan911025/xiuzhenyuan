<html>
 <head>
 <title>CSS</title>
 <style>
 .content{
  position:absolute;
  top:0;
  bottom:22%;
  left:20%;
  margin:auto;
  height:20%;
  width:70%;
         }
 .content div {
  width: 26%;
  padding-bottom:26%;
  border: 1% solid ; 
  border-radius:15%;         
  background-color: yellow; 
  float: left;
  margin:1%;
            }			
 </style>
 </head>
<body>
 <div class="content">
<div></div>
<div></div>
<div></div>
<div></div>
<div></div>
<div></div>
<div></div>
<div></div>
<div></div>
 </div>
</body>
</html>